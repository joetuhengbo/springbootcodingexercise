package com.telstra.codechallenge.hottestrepos.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * This model is used to receive the response of the git api.
 * */
@NoArgsConstructor
@Data
public class ApiResponseModel {

    private List<Repository> items;

}
