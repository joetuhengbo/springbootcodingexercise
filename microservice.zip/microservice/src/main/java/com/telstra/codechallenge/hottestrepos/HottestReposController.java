package com.telstra.codechallenge.hottestrepos;

import com.telstra.codechallenge.hottestrepos.model.ApiResponseModel;
import com.telstra.codechallenge.hottestrepos.model.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;


@RestController
public class HottestReposController {

    @Autowired
    RestTemplate restTemplate;

    @GetMapping("/hottestRepos")
    public List<Repository>  getTrendingRepos(
            @RequestParam("numOfRepos") Integer numOfRepos
    ){

        //-date for 7 days ago
        String date = LocalDate.now().minusDays(7).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        //-Get the trending repositories from the git api
        ApiResponseModel trendingRepos = restTemplate.getForObject("https://api.github.com/search/repositories?q=created:>"+date+"&sort=stars&order=desc", ApiResponseModel.class);

        //-Build a map of the language and the list of repositories using this language
        assert trendingRepos != null;

        //-Build the List of results
        return trendingRepos.getItems()
                .stream()
                .limit(numOfRepos)
                .collect(Collectors.toList());
    }
}

