package com.telstra.codechallenge.hottestrepos.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
 * Repository model is used to handle the list of items in the response of the git api
 **/

@NoArgsConstructor
@Data
public class Repository {
    private String name;
    private String language;
    private String html_url;
    private String watchers_count;
    private String description;
}
